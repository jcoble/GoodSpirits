alter table "public"."Transactions" drop constraint "Transactions_TransactionTypeId_fkey";
