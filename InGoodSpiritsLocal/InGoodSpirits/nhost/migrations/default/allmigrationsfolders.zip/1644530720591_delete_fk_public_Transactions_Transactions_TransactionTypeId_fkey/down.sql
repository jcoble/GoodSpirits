alter table "public"."Transactions"
  add constraint "Transactions_TransactionTypeId_fkey"
  foreign key ("TransactionTypeId")
  references "public"."TransactionType"
  ("Id") on update no action on delete no action;
