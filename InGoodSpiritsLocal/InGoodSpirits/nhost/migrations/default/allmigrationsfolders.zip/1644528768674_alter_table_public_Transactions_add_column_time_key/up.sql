alter table "public"."Transactions" add column "time_key" bigint
 not null;
