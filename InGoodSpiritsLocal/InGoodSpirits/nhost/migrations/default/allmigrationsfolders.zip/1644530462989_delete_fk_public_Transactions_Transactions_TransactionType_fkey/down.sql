alter table "public"."Transactions"
  add constraint "Transactions_TransactionType_fkey"
  foreign key ("TransactionType")
  references "public"."TransactionType"
  ("Id") on update no action on delete no action;
