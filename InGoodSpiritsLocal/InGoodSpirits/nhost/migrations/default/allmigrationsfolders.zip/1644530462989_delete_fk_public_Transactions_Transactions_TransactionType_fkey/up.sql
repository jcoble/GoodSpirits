alter table "public"."Transactions" drop constraint "Transactions_TransactionType_fkey";
