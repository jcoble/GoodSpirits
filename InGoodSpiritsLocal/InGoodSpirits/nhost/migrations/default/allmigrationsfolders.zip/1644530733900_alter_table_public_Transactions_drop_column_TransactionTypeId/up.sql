alter table "public"."Transactions" drop column "TransactionTypeId" cascade;
