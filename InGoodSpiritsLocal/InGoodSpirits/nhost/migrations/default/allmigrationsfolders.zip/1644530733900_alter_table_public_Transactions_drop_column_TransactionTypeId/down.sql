alter table "public"."Transactions" alter column "TransactionTypeId" drop not null;
alter table "public"."Transactions" add column "TransactionTypeId" int8;
